#include <stdio.h>
#include <stdlib.h>

int main()
{
    float numero;
    printf("Write a number\n");
    scanf("%f", &numero);
    printf("The predecessor of this number is: %f", (numero-1));

}
