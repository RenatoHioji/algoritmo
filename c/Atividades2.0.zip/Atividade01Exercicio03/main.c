#include <stdio.h>
#include <stdlib.h>

int main()
{
    int anos;

    printf("Write your age in years: \n");
    scanf("%d", &anos);
    printf("Your age in days will be: %d", (anos*365));



}
