#include <stdio.h>
#include <stdlib.h>

int main()
{
   int number;
   printf("Type a number \n");
   scanf("%d", &number);
   if(number >= 0){
        printf("This number is positive!!!!");
   }
   else{
    printf("This number is negative!!!!");
   }




}
