#include <stdio.h>
#include <stdlib.h>

int main()
{
    int counter = 0, number;
    while(counter <= 28){
    printf("Digite um valor");
    scanf("%d", &number);

    counter += 1;
    }
    printf("Congrats, you did it");
}
