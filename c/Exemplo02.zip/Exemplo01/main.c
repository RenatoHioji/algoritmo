 #include <stdio.h>
#include <stdlib.h>

int main()
{
  /*Char, int, float, double*/
  int numero1, numero2, soma;
  printf("Write the first number \n");
  scanf("%d", &numero1);
  printf("Write the second number \n");
  scanf("%d", &numero2);
  soma = (numero1+numero2);
  printf("The amount of the numbers is %d \n", soma);
}
